# LinkedIn SalesNavigator mark as read
This Google Chrome extension makes your life easier by marking all your notifications in the LinkedIn SalesNavigator as read.
Ever had 100+ unread notifications in your SalesNavigator and searched for a "mark all as read" button?
Stop searching!

# Development references
Docs: https://developer.chrome.com/docs/extensions/mv3/getstarted/development-basics/
Icon Generator: https://www.chromeextensionimages.com/

# Create publishing zipfile
```
zip -r chrome-extension-linkedin.zip . -x .git/\*
```